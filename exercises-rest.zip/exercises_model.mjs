import mongoose from 'mongoose';
import 'dotenv/config';

mongoose.connect(
    process.env.MONGODB_CONNECT_STRING,
    { useNewUrlParser: true }
);

const db = mongoose.connection;

const exerciseSchema = mongoose.Schema({
    name: { type: String, required: true},
    reps: { type: Number, required: true},
    weight: { type: Number, required: true},
    unit: { type: String, required: true},
    date: { type: String, required: true}
});

const Exercise = mongoose.model("exercise", exerciseSchema);

const createExercise = async (parameters) => {
    const exercise = new Exercise(parameters);
    return exercise.save();
}

const findExercises = async () => {
    const query = Exercise.find();
    return query.exec();
}

const findExercisesById = async (idParam) => {
    const query = Exercise.find(idParam);
    return query.exec();
}

const replaceExercise = async (filter, update) => {
    const result = await Exercise.updateOne(filter, update);
    return result.modifiedCount;
}

const deleteById = async (idParam) => {
    const result = await Exercise.deleteOne(idParam);
    return result.deletedCount;
}

db.once("open", () => {
    console.log("Successfully connected to MongoDB using Mongoose!");
});

export { createExercise, findExercises, findExercisesById, replaceExercise, deleteById };
