import 'dotenv/config';
import express from 'express';
import * as exercises from './exercises_model.mjs';

const app = express();

const PORT = process.env.PORT;

app.use(express.json());

function isDateValid(date) {
    const format = /^\d\d-\d\d-\d\d$/;
    return format.test(date);
}

function isValid(param) {
    if ((typeof param.name === 'string' && param.name.length > 0) &&
        (param.reps > 0 && param.weight > 0 && (param.reps * 10 % 10 === 0) && (param.weight * 10 % 10 === 0)) && 
        (param.unit === "kgs" || param.unit === "lbs") &&
        (isDateValid(param.date))) {
            return true
        }
    return false
}

app.post('/exercises', (req, res) => {
    const param = {name: req.body.name, reps: req.body.reps, weight: req.body.weight, unit: req.body.unit, date: req.body.date}

    if (isValid(param)) {
        exercises.createExercise(param)
        .then(exercise => {
            res.status(201).json(exercise);
        })
        .catch(error => {
            res.status(400).json({ Error: "Invalid request"});
        });
    } else {
        res.status(400).json({ Error: "Invalid request"});
    }
});

app.get('/exercises', (req, res) => {
    exercises.findExercises()
        .then( exercises => {
            res.status(200).json(exercises);
        })
        .catch(error => {
            console.error(error);
            res.send({ Error: 'Request failed' });
        });
});

app.get('/exercises/:_id', (req, res) => {
    const exerciseId = {_id: req.params._id};
    exercises.findExercisesById(exerciseId)
        .then( exercises => {
            if (exercises.length > 0) {
                res.status(200).json(exercises);
            } else {
                res.status(404).json({ Error: 'Not found' });
            }})
        .catch(error => {
            res.status(404).json({ Error: 'Not found' });
        });
});

app.put('/exercises/:_id', (req, res) => {
    const id = {_id: req.params._id}
    const param = {name: req.body.name, reps: req.body.reps, weight: req.body.weight, unit: req.body.unit, date: req.body.date}
    if (isValid(param)) {
        exercises.replaceExercise(id, param)
        .then(updateCount => {
                if (updateCount === 1) {
                    res.status(200).json({_id: req.params._id, name: req.body.name, reps: req.body.reps, weight: req.body.weight, unit: req.body.unit, date: req.body.date})
                } else {
                    res.status(404).json({ Error: 'Not found'});
                }})
        .catch(error => {
            res.status(404).json({ Error: 'Not found' });
        });
    } else {
        res.status(400).json({ Error: "Invalid request"});
    }
});

app.delete('/exercises/:_id', (req, res) => {
    const id = {_id: req.params._id}
    exercises.deleteById(id)
        .then(deleteCount => {
            if (deleteCount == 1) {
                res.status(204).send();
            } else {
                res.status(404).json({ Error: 'Not found'});
            }
        })
        .catch(error => {
            res.status(404).json({ Error: 'Not found'});
        });
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});