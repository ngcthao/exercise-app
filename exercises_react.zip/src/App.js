import './App.css';
import React from 'react';
import Navigation from './components/Navigation';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import CreateExercisePage from './pages/CreateExercisePage';
import EditExercisePage from './pages/EditExercisePage';
import { useState } from 'react';

function App() {
  const [exerciseToEdit, setExerciseToEdit] = useState();

  return (
    <>
    <header>
    <h1>Exercise Log</h1>
    <p>
      Log your exercise for the day to keep track of your progress!
    </p>
    </header>
    <body>
    <div className="App">
      <Router>
        <div className="navigate"><Navigation/></div>
        <div className="App-body">
          <Routes>
                <Route path="/" element={<HomePage setExerciseToEdit={setExerciseToEdit}/>}/>
                <Route path="/create-exercise" element={<CreateExercisePage/>}/>
                <Route path="/edit-exercise" element={ <EditExercisePage exerciseToEdit={exerciseToEdit}/>}/>
          </Routes>
        </div></Router>
    </div>
    </body>
    <footer>© 2023 Ngoc-Thao Ly</footer>
    </>
  );
}

export default App;
